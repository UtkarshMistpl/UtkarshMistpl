import react from "react";


const ChatFeed = (props) => {
    console.log(props);
    return (
    <div style={{display:"none"}}>
      
    
    </div>);
}
 
export default ChatFeed;