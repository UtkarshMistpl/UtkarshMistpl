-- INSERT INTO substituteplayer

--c substituteplayer

INSERT INTO sport_center (address) VALUE("Dwarka Dham Club House, New Jail Road, Abbas Nagar, Gandhi Nagar, Bhopal, Madhya Pradesh, India");

CREATE TABLE sport_center(
    center_id SERIAL PRIMARY KEY,
      name varchar(255),
      sport varchar(255),
      address varchar(255), 
      phone varchar(255),
      email varchar(255),
      days varchar(255),
      _from time(6),
      _to time(6),
      fee varchar(255)
);